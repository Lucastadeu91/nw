<!DOCTYPE html>
<html>
	<head>

		<?php include 'include/head.php'; ?>

	</head>
	<body>
		<div class="body">
			<?php include 'include/header.php';?>

			<div role="main" class="main">
				<div class="slider-container rev_slider_wrapper" style="height: 700px;">
					
					<div id="revolutionSlider" class="slider rev_slider" data-plugin-revolution-slider data-plugin-options="{'delay': 9000, 'gridwidth': 800, 'gridheight': 1080}">
						<ul>
							<li data-transition="fade">
								<img src="img/slides/new-black-banner.jpg"  
									alt=""
									data-bgposition="center center" 
									data-bgfit="cover" 
									data-bgrepeat="no-repeat" 
									class="rev-slidebg">

								<div class="tp-caption"
									data-x="center" data-hoffset="-460"
									data-y="center" data-voffset="175"
									data-start="1000"
									style="z-index: 5"
									data-transform_in="x:[-300%];opacity:0;s:500;"><img src="img/Mouse-de-rolagem.png" alt=""></div>

							</li>
							
						</ul>
					</div>
				</div>
				<div class="container">
					<section class="section section-default">
						<div class="container">
							<div class="row">
								<div class="col-md-12 txtcenter">
									<h2 class="mb-0 bold">VEJA QUEM JÁ É NEW BLACK</h2>
									<div class="row">
										<div class="col-md-12 mt-md">
											
											<div class="owl-carousel owl-theme stage-margin" data-plugin-options="{'items': 5, 'margin': 10, 'loop': false, 'nav': true, 'dots': false, 'stagePadding': 40}">
												<div>
													<img alt="" class="img-responsive img-rounded" src="img/nw-clientes-rap-descarte-certo.png">
												</div>
												<div>
													<img alt="" class="img-responsive img-rounded" src="img/nw-clientes-rap-burguer.png">
												</div>
												<div>
													<img alt="" class="img-responsive img-rounded" src="img/nw-clientes-rap-rede-de-profissionais-negros.png">
												</div>
												<div>
													<img alt="" class="img-responsive img-rounded" src="img/nw-clientes-rap-tractus-print.png">
												</div>
												<div>
													<img alt="" class="img-responsive img-rounded" src="img/nw-clientes-rap-ewa.png">
												</div>
												
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12 txtcenter mt-md">
									<div class="btn btn-secondary" style="border-radius: 100px;"><h3 class="mb-none text-color-primary">SAIBA MAIS</h3></div>
								</div>
							</div>
						</div>
					</section>
				</div>
				<section class="section section-text-light section-background section-center mb-none" style="background-image: url(img/background.jpg);" id="servicos">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<h2 class="bold">NOSSOS SERVIÇOS</h2>
								<p class="mb-none text-color-quaternary">Somos uma agência 360° que transforma ideias  em comunicações edicientes. marcas em cases e estratégia em resultados.</p>
							</div>
						</div>
						<div class="row servicos-img">
							<div class="col-md-2 col-md-offset-1">
								<div class="p-xlg">
									<img src="img/icons/nw-servicos-1.png" class="marginauto img-responsive appear-animation" data-appear-animation="rotateIn" data-appear-animation-delay="0" data-appear-animation-duration="1s" alt="new-black-serviços-1">
								</div>
							</div>
							<div class="col-md-2">
								<div class="p-xlg">
									<img src="img/icons/nw-servicos-2.png" class="marginauto img-responsive appear-animation" data-appear-animation="rotateIn" data-appear-animation-delay="100" data-appear-animation-duration="1s" alt="new-black-serviços-2">
								</div>
							</div>
							<div class="col-md-2">
								<div class="p-xlg">
									<img src="img/icons/nw-servicos-3.png" class="marginauto img-responsive appear-animation" data-appear-animation="rotateIn" data-appear-animation-delay="200" data-appear-animation-duration="1s" alt="new-black-serviços-3">
								</div>
							</div>
							<div class="col-md-2">
								<div class="p-xlg">
									<img src="img/icons/nw-servicos-4.png" class="marginauto img-responsive appear-animation" data-appear-animation="rotateIn" data-appear-animation-delay="300" data-appear-animation-duration="1s" alt="new-black-serviços-4">
								</div>
							</div>
							<div class="col-md-2">
								<div class="p-xlg">
									<img src="img/icons/nw-servicos-5.png" class="marginauto img-responsive appear-animation" data-appear-animation="rotateIn" data-appear-animation-delay="400" data-appear-animation-duration="1s" alt="new-black-serviços-5">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 txtcenter mt-md">
								<div class="btn btn-light" style="border-radius: 100px;"><h3 class="mb-none text-color-secondary">SAIBA MAIS</h3></div>
							</div>
						</div>
					</div>
				</section>
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12 p-none">
							<div class="nivo-slider">
								<div class="slider-wrapper theme-default">
									<div id="nivoSlider" class="nivoSlider mt-none">
										<img src="img/slides/banner-cliente-1.jpg" data-thumb="img/slides/banner-cliente-1.jpg" alt="" />
										<img src="img/slides/banner-cliente-2.jpg" data-thumb="img/slides/banner-cliente-1.jpg" alt="" />
										<img src="img/slides/banner-cliente-3.jpg" data-thumb="img/slides/banner-cliente-1.jpg" alt="" />
										
										
									</div>
									<div id="htmlcaption" class="nivo-html-caption"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="form-group news txtcenter mt-xlg">
								<div class="row">
									<div class="col-xs-8 col-md-8 col-md-offset-1 p-none">
										<input type="text" placeholder="Receba nossas news" class="form-control input-lg">
									</div>
									<div class="col-xs-2 col-md-2 p-none txtleft">
										<div class="btn btn-secondary btn-lg ">Enviar</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- <div class="slider-container rev_slider_wrapper" style="height: 600px;">
					
					<div id="revolutionSlider" class="slider rev_slider" data-plugin-revolution-slider data-plugin-options="{'delay': 9000, 'gridwidth': 600, 'gridheight': 1080}">
						<ul>
							<li data-transition="fade">
								<img src="img/slides/banner-cliente-1.jpg"  
									alt=""
									data-bgposition="center center" 
									data-bgfit="cover" 
									data-bgrepeat="no-repeat" 
									class="rev-slidebg">
				
							</li>
							<li data-transition="fade">
								<img src="img/slides/banner-cliente-2.jpg"  
									alt=""
									data-bgposition="center center" 
									data-bgfit="cover" 
									data-bgrepeat="no-repeat" 
									class="rev-slidebg">
				
							</li>
							<li data-transition="fade">
								<img src="img/slides/banner-cliente-3.jpg"  
									alt=""
									data-bgposition="center center" 
									data-bgfit="cover" 
									data-bgrepeat="no-repeat" 
									class="rev-slidebg">
				
							</li>
							
						</ul>
					</div>
				</div> -->
				
		
				
				

				
				
			</div>
 
			<?php include 'include/footer.php' ?>
		</div>

		<!-- Vendor -->
		<?php include 'include/jsFile.php'; ?>
		<!-- Google Analytics: Change UA-XXXXX-X to be your site's ID. Go to http://www.google.com/analytics/ for more information.
		<script>
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
		
			ga('create', 'UA-12345678-1', 'auto');
			ga('send', 'pageview');
		</script>
		 -->

	</body>
</html>