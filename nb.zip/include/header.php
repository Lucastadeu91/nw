<header id="header" data-plugin-options="{'stickyEnabled': true, 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyStartAt': 57, 'stickySetTop': '-12px', 'stickyChangeLogo': true}">
	<div class="header-body">
		<div class="header-container container">
			<div class="header-row">
				<div class="header-column">
					<div class="header-logo">
						<a href="index.html">
							<img alt="Porto" width="111" height="65" data-sticky-width="82" data-sticky-height="50" data-sticky-top="5px" src="img/logo.png">
						</a>
					</div>
				</div>
				<div class="header-column">
					<div class="header-row">
						<div class="header-nav">
							<button class="btn header-btn-collapse-nav" data-toggle="collapse" data-target=".header-nav-main">
								<i class="fa fa-bars"></i>
							</button>
							
							<div class="header-nav-main header-nav-main-effect-1 header-nav-main-sub-effect-1 collapse">
								<nav>
									<ul class="nav nav-pills" id="mainNav">
										
										<li class="">
											<a href="sobre.home">
												Sobre 
											</a>
										</li>
										<li class="">
											<a href="serviços.home">
												Serviços
											</a>
										</li>
										<li class="">
											<a href="portfolio.home">
												Portfá
											</a>
										</li>
										<li class="">
											<a href="equipe.home">
												Equipe
											</a>
										</li>
										<li class="">
											<a href="contato.home">
												Contato
											</a>
										</li>
										<!-- <li class="dropdown">
											<a class="dropdown-toggle" href="#">
												Contact Us
											</a>
											<ul class="dropdown-menu">
												<li><a href="contact-us.html">Contact Us - Basic</a></li>
												<li><a href="contact-us-advanced.php">Contact Us - Advanced</a></li>
											</ul>
										</li> -->
									</ul>
								</nav>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</header>