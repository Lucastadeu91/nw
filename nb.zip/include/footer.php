<footer id="footer">
	
	<div class="footer-copyright">
		<div class="container">
			<div class="row">
				<div class="col-md-1">
					<a href="index.html" class="logo">
						<img alt="New Black Logo" class="img-responsive" src="img/nb-logo-fotter.png">
					</a>
				</div>
				<div class="col-md-7 mt-xlg pt-xs">
					<h3 class="text-color-light bold"><a href="">FALE CONOSCO</a></h3>
				</div>
				<div class="col-md-4">
					<nav id="sub-menu">
						<ul class="header-social-icons social-icons hidden-xs">
							<li class=""><a href="http://www.facebook.com/" target="_blank" title="Facebook"><i class="fa fa-facebook fa-3x" style="position: relative;left: 5px;bottom: -10px;"></i></a></li>
							<li class=""><a href="http://www.instagram.com/" target="_blank" title="Instagram"><i class="fa fa-instagram fa-3x"></i></a></li>
							<li class=""><a href="http://www.linkedin.com/" target="_blank" title="Linkedin"><i class="fa fa-linkedin fa-3x"></i></a></li>
						</ul>
					</nav>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 left">
					<p class="">Rua Restinga, 113 - sala 1606 - Tatuapé, São Paulo - SP</p>
					<p class="">+55 11 9 7509-5016 - contato@nwb.agency</p>
				</div>
			</div>
		</div>
	</div>
</footer>